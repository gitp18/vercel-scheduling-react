import axios from 'axios';
import React, { useState, useEffect } from 'react';
import './App.css';

function App() {

  const [tableState, setTableState] = useState({
    days: [],
    products: [],
    displayData: [],
    displayProducts: [],
    seletedDay: "",
    selectedProduct: [],
    selectedData: []
  });

  useEffect(() => {
    axios.get('https://vercel-nodejs-two.vercel.app/api/user/scheduleData').then(result => {
      if (result.status === 200) {
        let { days, displayData, products } = result.data;
        setTableState({
          ...tableState,
          days: Object.entries(days),
          products: Object.entries(products),
          displayData: Object.entries(displayData)
        });
      }
    });
  }, []);

  const onChangeHandler = (e) => {
    let seletedDay = e.target.value;
    let product = tableState.products.filter(([key]) => key === seletedDay)[0];
    setTableState({
      ...tableState,
      seletedDay: seletedDay,
      displayProducts: product[1],
      selectedProduct: []
    });
  }

  const onClickHandler = (e) => {
    let selectProduct = e.target.value;
    let allProducts = tableState?.selectedProduct;
    if (e.target.checked) {
      allProducts = [...allProducts, selectProduct];
      setTableState({
        ...tableState,
        selectedProduct: allProducts
      })
    } else {
      let filterData = tableState.selectedProduct.filter(item => item !== selectProduct);
      setTableState({
        ...tableState,
        selectedProduct: filterData
      })
    }
  }

  const onSubmitHandler = () => {
    let { displayData, seletedDay, selectedProduct } = tableState;
    let selectedData = displayData.filter(item => item[0] == seletedDay + selectedProduct.join(''))[0];
    setTableState({
      ...tableState,
      selectedData: selectedData[1].tableData
    })
  }

  return (
    <div className="App">
      <select onChange={(e) => onChangeHandler(e)}>
        {
          tableState.days.map(([firstItem, secondItem], index) => {
            return (
              <option key={index} value={firstItem + ''}>{secondItem + ' days'}</option>
            )
          })
        }
      </select>
      <div>
        {
          tableState?.displayProducts?.map((item, index) => {
            return (
              <React.Fragment key={"product" + item.name}>
                <input type={'checkbox'} name={"product" + index} checked={tableState.selectedProduct.includes(item.name)} onChange={(e) => onClickHandler(e)} value={item.name} />
                <label forhtml={"product" + index}>{item.name}</label>
              </React.Fragment>
            )
          })
        }
      </div>

      <button type={'button'} onClick={onSubmitHandler}>Submit</button>

      <table>
        <thead>
          <tr>
            {
              tableState?.selectedData[0]?.map(item => <td>{item}</td>)
            }
          </tr>
        </thead>
        <tbody>
          {
            tableState.selectedData.map((item, index) => {
              if (index === 0) return null;
              return (
                <tr key={'d' + index}>
                  {
                    item.map((tItem, tindex) => {
                      return <td key={tindex}>{tItem}</td>
                    })
                  }
                </tr>
              )
            })
          }
        </tbody>
      </table>


    </div>
  );
}

export default App;
